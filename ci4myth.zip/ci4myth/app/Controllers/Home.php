<?php

namespace App\Controllers;

class Home extends BaseController
{


    public function index()
    {
        return view('welcome_message');
    }

    public function login()
    {
        $data = [
            'title' => 'login',
            'config' => config('Auth'),
        ];

        return view('auth/login', $data);
    }

    public function register()
    {
        $data['title'] = 'register';

        return view('auth/register', $data);
    }
}
