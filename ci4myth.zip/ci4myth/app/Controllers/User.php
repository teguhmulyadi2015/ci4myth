<?php

namespace App\Controllers;

class User extends BaseController
{


    public function index()
    {
        $data['title'] = 'My Profile';
        return view('user/index', $data);
    }

    public function change_password()
    {
        return view('user/change_password');
    }

    // public function login()
    // {
    //     $data = [
    //         'title' => 'login',
    //         'config' => config('Auth'),
    //     ];

    //     return view('auth/login', $data);
    // }

    // public function register()
    // {
    //     $data['title'] = 'register';

    //     return view('auth/register', $data);
    // }
}
